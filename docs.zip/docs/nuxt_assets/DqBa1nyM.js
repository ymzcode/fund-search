import{D as n,b as t}from"./BpQzHZb_.js";n.Button=t;n.install=function(o){return o.component(n.name,n),o.component(t.name,t),o};
